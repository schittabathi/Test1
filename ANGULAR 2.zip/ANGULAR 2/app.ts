//our root app component
import {Component, NgModule} from '@angular/core'
import {BrowserModule} from '@angular/platform-browser'

import {TabSet} from './tabs';
import {Tab} from './tab';

@Component({
  selector: 'tabs-app',
  template: `
    <tabset>
      <tab [tabTitle]="'Home'">
      Home Tab Content
      </tab>
      <tab [tabTitle]="'About'">
      About Tab Content
      </tab>
    </tabset>
  `
})
class App {
  constructor() {
  }
}

@NgModule({
  imports: [ 
    BrowserModule
    ],
  declarations: [ 
    App, 
    TabSet, 
    Tab 
    ],
  bootstrap: [ 
    App
    ]
})
export class AppModule {}