var app = angular.module('app', []);
app.service('CommonDataService', CommonDataService );
CommonDataService.$injector = ['$http', '$q'];
function CommonDataService($http, $q){
  this.getApiData = getApiData;
  function getApiData(url){
    var deferred = $q.defer();
     $http.get(url)
       .then(function(data) { 
          deferred.resolve(data);
       }).catch(function(msg, code) {
         

       });

     return deferred.promise;

  }
}
app.controller('HomeController', HomeController);
HomeController.$injector = ['CommonDataService'];
function HomeController(CommonDataService){
  var ctrl = this;
  ctrl.searchRepository = searchRepository;
  ctrl.getAllRepos = getAllRepos;
  ctrl.allRepos = [];
  ctrl.repository = {};
  function searchRepository(){
    var url = "https://api.github.com/users/" + ctrl.searchInput
    var promise = CommonDataService.getApiData(url);
    promise.then(function(response){
      console.log('33', response.data);
      ctrl.repository = response.data;
      ctrl.getAllRepos();
    })
  }
  
  function getAllRepos(){
    var url = "https://api.github.com/users/" + ctrl.searchInput + "/repos";
     var promise = CommonDataService.getApiData(url);
    promise.then(function(response){
     ctrl.allRepos = response.data;
    })
  }
  
}